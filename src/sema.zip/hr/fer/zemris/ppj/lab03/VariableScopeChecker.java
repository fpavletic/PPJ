package hr.fer.zemris.ppj.lab03;

import hr.fer.zemris.ppj.lab01.Symbol;
import hr.fer.zemris.ppj.lab01.Token;
import hr.fer.zemris.ppj.lab02.Node;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class VariableScopeChecker {

    private Node root;
    private List<String> output;

    public VariableScopeChecker(Node root) {
        this.root = root;
    }

    public List<String> checkScopes(){

        if ( output == null ) {
            output = new LinkedList<>();
            try {
                checkBlockScope(root, new HashMap<>(), output);
            } catch (UndeclaredVariableException e) {
                output.clear();
                output.add(e.getMessage());
            }
        }
        return output;
    }

    private void checkBlockScope(Node node, Map<String, Integer> liveVariables, List<String> output) throws UndeclaredVariableException {

        Token token = node.token();

        //If token is an identifier
        if ( token.symbol() == Symbol.IDN){

            // and is declared
            if ( liveVariables.keySet().contains(token.value())) {
                // add to output
                output.add(String.format("%d %d %s", token.lineIndex(), liveVariables.get(token.value()), token.value()));
            // and is not declared
            } else {
                // is being declaration
                if ( token.next().symbol() == Symbol.OP_ASSIGN || token.next().symbol() == Symbol.FROM){
                    // add to scope
                    liveVariables.put(token.value(), token.lineIndex());
                } else {
                    throw new UndeclaredVariableException(String.format("err %d %s", token.lineIndex(), token.value()));
                }
            }
        }

        if ( token.symbol().isCreatesScope() ){
            Map<String, Integer> newScope = new HashMap<>();
            liveVariables.forEach( newScope::put );
            for ( Node child : node.children() ){
                checkBlockScope(child, newScope, output);
            }
        } else {
            for ( Node child : node.children()){
                checkBlockScope(child, liveVariables, output);
            }
        }

    }

}

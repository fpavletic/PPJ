package hr.fer.zemris.ppj.lab02;

import hr.fer.zemris.ppj.lab01.Symbol;
import hr.fer.zemris.ppj.lab01.Token;

import java.io.PrintStream;
import java.util.LinkedList;
import java.util.List;

public class Node {

    private List<Node> children;
    private Token token;
    private Node parent;

    public Node(Token token, Node parent) {
        this.token = token;
        this.parent = parent;
        children = new LinkedList<>();
    }

    public Node(String text, Node parent) {
        this(new Token(text), parent);
    }

    public Node(Symbol symbol, Node parent) {
        this(new Token(null, symbol, -1), parent);
    }

    public Node(Token token) {
        this(token, null);
    }

    public Node(String text) {
        this(text, null);
    }

    public Node(Symbol s) {
        this(s, null);
    }

    public Node parent(int count) {
        if (count < 0) {
            return this;
        }
        if (count == 0) {
            return this;
        }
        if (parent == null) {
            throw new RuntimeException(this + " has no parent!");
        }
        return parent.parent(count - 1);
    }

    public List<Node> children() {
        return children;
    }

    public void addChild(Node child) {
        children.add(child);
    }

    public void addChild(Token child) {
        addChild(new Node(child));
    }

    public void addChild(String child) {
        addChild(new Node(child));
    }

    public void addChild(Symbol child) {
        addChild(new Node(child));
    }

    public void addChildren(List<Node> children) {
        this.children.addAll(children);
    }

    public void addChildren(Token[] children) {
        for (Token child : children) {
            addChild(child);
        }
    }

    public String toString() {
        return token.toString();
    }

    public void print(int indentation, PrintStream output) {

        output.format("%" + (indentation > 0 ? indentation : "") + "s%s\n", "", token.toString());
        for (Node child : children) {
            child.print(indentation + 1, output);
        }
    }

    public Token token() {
        return token;
    }
}

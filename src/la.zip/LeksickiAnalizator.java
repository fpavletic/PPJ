import java.io.FileNotFoundException;
import java.util.Scanner;

public class LeksickiAnalizator {
    @SuppressWarnings("resource")
    public static void main(String[] args) throws FileNotFoundException {

        String text = new Scanner(System.in).useDelimiter("\\Z").next();
        //String text = new Scanner(new File("./primjer.in")).useDelimiter("\\Z").next();
        hr.fer.zemris.ppj.lab01.Tokenizer PBJLove = new hr.fer.zemris.ppj.lab01.Tokenizer(text);
        while ( PBJLove.hasNext() ){
            System.out.println(PBJLove.next());
        }

    }
}

package hr.fer.zemris.ppj.lab03;

public class UndeclaredVariableException extends Exception{
    public UndeclaredVariableException(String message) {
        super(message);
    }
}
